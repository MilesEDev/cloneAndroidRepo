﻿using System;

public class initiator
{
	int layers = 0;
	int neuroninfirst = 0;
	int neuroninlast = 0;

	public Class1()
	{
		
	}
	public void get_User_Input()
	{

		

		

	}


}
