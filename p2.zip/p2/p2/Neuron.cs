﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p2
{
    internal class Neuron
    {
        private double activation;
        private double[] weights;
        private LinkedList<double>[]weightUpdates;


        public Neuron(float activation)
        {
            this.activation = activation;
            
           
        }
        
        public double getActivation() { return activation; }
        public double[] getWeights() { return weights;}

        public void setWeights(int nextLayerNeuronCount)
        {
            this.weights = new double[nextLayerNeuronCount];
           
            Random weight_Generator = new Random();
            
            for(int weightCounter = 0;weightCounter < nextLayerNeuronCount; weightCounter++)
            {
                double Weightvalue = weight_Generator.NextDouble();
                weights[weightCounter] = Weightvalue;

            }

        }
        public void setWeightUpdates(int nextlayerNeuronCount,int updateValue)
        {


        }
        public LinkedList<double>[] getWeightUpdates() 
        { 
            return weightUpdates;
        }


        public void setActivation(double activation)
        {

            this.activation = activation;
        }

        public void toString()
        {
            Console.WriteLine("this is the activation" + " " + activation +
                "\n this is the set of weights");
            foreach(double weight in weights)
            {
                
                Console.WriteLine(weight);

            }

        }
    }
}
