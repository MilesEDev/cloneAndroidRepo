﻿

using p2;

namespace NN
{
    class mainclass
    {



        static void Main(string[] args)
        {

            initiator myobj = new initiator();
            myobj.get_User_Input();
            myobj.setNetwork();
            Network mynetwork = myobj.GetNetwork();

            mynetwork.createWeights();
            mynetwork.toString();
            mynetwork.setInputLayerActivation();
            mynetwork.forwardPropagation();
            mynetwork.toString();






        }
    }
}