﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace p2
{
    internal class Network
    {

        Neuron[][] neural_Network_Instance;
        double[] desiredOutputs;


        public Network(int hiddenLayers, int neuronCountForInput, int neuronCountForOutput, int neuronCountForHidden)
        {
            int layer_Index = 0;
            this.desiredOutputs = new double[neuronCountForOutput];
            this.neural_Network_Instance = new Neuron[hiddenLayers + 2][];//plus two for first and last layer (count does not factor in 0 start index)

            neural_Network_Instance[layer_Index] = setNeurons(neuronCountForInput);
            for (layer_Index = 1; layer_Index < hiddenLayers; layer_Index++)
            {
                neural_Network_Instance[layer_Index] = setNeurons(neuronCountForHidden);
                Console.WriteLine("this is the l index" + layer_Index);
            }
            Console.WriteLine("this is the l index after looop" + layer_Index);
            neural_Network_Instance[layer_Index] = setNeurons(neuronCountForHidden);

            neural_Network_Instance[1 + layer_Index] = setNeurons(neuronCountForOutput);


        }
        public double sigmoid(double value)
        {
            return 1.0f / (1.0f + (float)Math.Exp(-value));
        }
        public double sigmoidDerivative(double value)
        {

            return 1 - (sigmoid(value));

        }
        public void createWeights()
        {
            for (int layer_Index = 0; layer_Index < neural_Network_Instance.Length - 1; layer_Index++)//-1 to not run on last layer
            {
                foreach (Neuron thisNeuron in neural_Network_Instance[layer_Index])
                {
                    thisNeuron.setWeights(neural_Network_Instance[layer_Index + 1].Length);
                    Console.WriteLine("this is layer index in create weights" + layer_Index);

                }

            }
        }
        public void setInputLayerActivation()
        {
            foreach (Neuron Thisneuron in neural_Network_Instance[0])
            {
                Console.WriteLine("input activation for input neuron");
                double activation = Convert.ToDouble(Console.ReadLine());
                Thisneuron.setActivation(activation);

            }

        }
        public void setDesiredOutputs()
        {

            for (int i = 0; i < neural_Network_Instance[neural_Network_Instance.Length].Length; i++)
            {

                Console.WriteLine("what desired output would you like for output neuron " + i);
                double singleDesiredOutput = Convert.ToDouble(Console.ReadLine());
                desiredOutputs[i] = singleDesiredOutput;

            }

        }

        public double[] calcWeightActivationSum(int layer_Index)
        {
            double[] sum_WeightAndActivationArray = new double[neural_Network_Instance[layer_Index].Length];
            double sum_WeightAndActivation = 0;
            for (int weight_Index = 0; weight_Index < neural_Network_Instance[layer_Index].Length; weight_Index++)
            {

                foreach (Neuron thisNeuron in neural_Network_Instance[layer_Index])
                {
                    double calcThisNeuronOutput = thisNeuron.getActivation() * thisNeuron.getWeights()[weight_Index];
                    sum_WeightAndActivation = sum_WeightAndActivation + calcThisNeuronOutput;


                }
                sum_WeightAndActivationArray[weight_Index] = sum_WeightAndActivation;


            }
            return sum_WeightAndActivationArray;


        }

        public void forwardPropagation()
        {


            for (int layer_Index = 0; layer_Index < neural_Network_Instance.Length - 1; layer_Index++)
            {
                double[] updateArray = calcWeightActivationSum(layer_Index);
                for (int updateArrayIndex = 0; updateArrayIndex < updateArray.Length; updateArrayIndex++)
                {

                    neural_Network_Instance[layer_Index + 1][updateArrayIndex].setActivation(sigmoid(updateArray[updateArrayIndex]));


                }


            }

        }



      
        public void backPropagation()//needs tweaking 
        {
            double derviativeCostToActivation = 0;
            double costToActivation = 0;

            for (int layer_index = neural_Network_Instance.Length; layer_index >0; layer_index--)
            {


                for (int neuronIndex = 0; neuronIndex < neural_Network_Instance[layer_index].Length;neuronIndex++ )
                {
                    Neuron thisNueron = neural_Network_Instance[layer_index][neuronIndex];
                    double[] weights = thisNueron.getWeights();
                    double[] forwardPropUpdateValues = calcWeightActivationSum(layer_index);
                    
                    foreach (Neuron thisNeuron in neural_Network_Instance[layer_index])
                    {
                        if (layer_index == neural_Network_Instance.Length)
                        {

                            double priorCostToActivation = (thisNueron.getActivation() - desiredOutputs[neuronIndex]) * 2;
                            for(int weight_Index = 0; weight_Index < weights.Length; weight_Index++)
                            {

                                costToActivation += thisNeuron.getWeights()[weight_Index] *  forwardPropUpdateValues[weight_Index] * priorCostToActivation;
                            }
                        }
                        else
                        {
                            costToActivation = derviativeCostToActivation;
                        }
                    }
                    for (int weight_Index = 0; weight_Index < weights.Length; weight_Index++)
                    {
                        double derivativeCosttoActivation = weights[weight_Index] * sigmoidDerivative(forwardPropUpdateValues[weight_Index]);
                    }

                }
            }
        }




        public Neuron[] setNeurons(int thisLayerCount)
        {
            Neuron[] Thislayer = new Neuron[thisLayerCount];

            for (int i = 0; i < thisLayerCount; i++)
            {
                Neuron Thislayerneuron = new Neuron(0);
                Thislayer[i] = Thislayerneuron;
            }
            return Thislayer;
        }
        public void readLayer(int layer_index)
        {
            foreach (Neuron thisNeuron in neural_Network_Instance[layer_index])
            {
                thisNeuron.toString();
            }

        }

        public void toString()
        {
            int layer_index = 0;
            Console.WriteLine("the neurons for the input layer");
            readLayer(layer_index);
            Console.WriteLine("these are the neurons for hidden layers");
            for (layer_index = 1; layer_index < neural_Network_Instance.Length - 1; layer_index++)
            {
                Console.WriteLine("hidden layer " + layer_index);
                readLayer(layer_index);

            }
            Console.WriteLine("these are the neurons for output layer");
            foreach (Neuron thisNeuron in neural_Network_Instance[layer_index])
            {
                Console.WriteLine("this is activation on output layer" + thisNeuron.getActivation());
            }

        }



    }
}

