﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p2
{
    internal class initiator
    {
        private int Hiddenlayers = 0;
        private int neuronInFirst = 0;
        private int neuronInLast = 0;
        private int neuronInHidden = 0;
        Network mynetwork;
        


        public initiator()
        {
            Console.WriteLine("hi");

        }
        public void get_User_Input()
        {
            Console.WriteLine("how many hidden layers");
            this.Hiddenlayers = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("how many neuron in first layer");
            this.neuronInFirst = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("how many neurons in the last layer");
            this.neuronInLast = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("how many neurons in the hidden layers");
            this.neuronInHidden = Convert.ToInt16(Console.ReadLine());


        }

        public void setNetwork()//this needs to be altered after adding the neuron class 
        {

            Network mynetwork = new Network(this.Hiddenlayers, this.neuronInFirst, this.neuronInLast, this.neuronInHidden);

        }
        public Network GetNetwork()
        {
            return new Network(this.Hiddenlayers, this.neuronInFirst, this.neuronInLast, this.neuronInHidden);
        }
       
  
    }
    
}
